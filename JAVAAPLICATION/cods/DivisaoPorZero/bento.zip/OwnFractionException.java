public class OwnFractionException extends ArithmeticException {

	public OwnFractionException () {
		super();
	}
	
	public OwnFractionException (String message) {
		super(message);
	}	
	
}
