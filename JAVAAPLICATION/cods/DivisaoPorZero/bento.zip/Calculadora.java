public class Calculadora {
	public static int dividir(int numerador, int denominador) 
		throws ArithmeticException {
		return numerador / denominador;
	}	
	
}//fim da classe calculadora
