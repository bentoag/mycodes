package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.DataBase;
import model.MasterPanel;
import model.Question;

//classe que permite a inser��o de quest�es preenchendo o formulario
public class FormPanel extends MasterPanel {
	private MainFrame mainFrame;
	private JLabel label;
	private JButton backButton;
	private JButton saveButton;
	private JTextArea question;
	private JTextField id;
	private JTextField answer;
	private Question qst;

	public void setQst(Question qst) {
		this.qst = qst;
	}

	public FormPanel(MainFrame mainFrame) {
		this.mainFrame = mainFrame;
		setLayout(null);
		qst = null;
		start();
	}

	public JTextArea getQuestion() {
		return question;
	}

	public JTextField getAnswer() {
		return answer;
	}

	public Question getQst() {
		return qst;
	}

	private void start() {
		label = new JLabel("<html><b>Formul�rio</b></html>");
		label.setFont(new Font("Arial", Font.PLAIN, 50));
		label.setForeground(Color.ORANGE);
		addComponent(label, 500, 50, 300, 70);

		createButtons();
		createForm();
	}

	private void createButtons() {
		backButton = new JButton("VOLTAR");
		backButton.setBackground(Color.RED);
		backButton.setForeground(Color.WHITE);
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mainFrame.showAdmin();
				clearFields();

			}
		});
		addComponent(backButton, 50, 50, 100, 25);

		saveButton = new JButton("SALVAR");
		saveButton.setBackground(Color.ORANGE);
		saveButton.setForeground(Color.WHITE);
		saveButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Question qst = new Question ();
				
				if (FormPanel.this.qst == null) {
					if (question.getText().equals("") || answer.getText().equals("")) {
						JOptionPane.showMessageDialog(FormPanel.this, "Preencha os campos necess�rios");
					} else {
						qst.setQuestion(question.getText());
						qst.setAnswer(answer.getText());
						DataBase.insert(qst);
						JOptionPane.showMessageDialog(FormPanel.this, "Pergunta adicionada com sucesso");
						mainFrame.showAdmin();
						clearFields();
					}
				} else {
					qst.setId(Integer.parseInt(id.getText()));
					if (question.getText().equals("") || answer.getText().equals("")) {
						JOptionPane.showMessageDialog(FormPanel.this, "Preencha os campos necess�rios");
					} else {
						qst.setQuestion(question.getText());
						qst.setAnswer(answer.getText());
						DataBase.update(qst);
						JOptionPane.showMessageDialog(FormPanel.this, "Pergunta adicionada com sucesso");
						mainFrame.showAdmin();
						clearFields();
					}
				}
			}
		});
		addComponent(saveButton, 550, 480, 200, 50);
	}

	private void createForm() {
		label = new JLabel("ID");
		label.setFont(new Font("Arial", Font.PLAIN, 25));
		addComponent(label, 180, 250, 300, 25);
		id = new JTextField(4);
		id.setEditable(false);
		addComponent(id, 300, 240, 700, 50);

		label = new JLabel("Quest�o");
		label.setFont(new Font("Arial", Font.PLAIN, 25));
		addComponent(label, 180, 310, 300, 25);
		question = new JTextArea(5, 30);
		JScrollPane scrollPane = new JScrollPane(question);
		addComponent(scrollPane, 300, 300, 700, 50);

		label = new JLabel("Resposta");
		label.setFont(new Font("Arial", Font.PLAIN, 25));
		addComponent(label, 180, 370, 300, 25);
		answer = new JTextField(50);
		addComponent(answer, 300, 360, 700, 50);
	}

	private void clearFields() {
		id.setText("");
		question.setText("");
		answer.setText("");
	}

	public void setFields() {
		if (qst != null) {
			id.setText(Integer.toString(qst.getId()));
			question.setText(qst.getQuestion());
			answer.setText(qst.getAnswer());
		}
	}

}
