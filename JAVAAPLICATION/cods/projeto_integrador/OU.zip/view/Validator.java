package view;

public class Validator {
	public FormPanel formPanel;

	public Validator(FormPanel formPanel) {
		this.formPanel = formPanel;
	}
	
	public void validate() {}
	
}
