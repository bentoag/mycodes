package gerenciador.bento;

public class Gerenciador {

	public static void main(String[] args) {
		final Mes ABRIL = Mes.ABRIL;
		final Mes MAIO = Mes.MAIO;
		final Mes OUTUBRO = Mes.OUTUBRO;
		final Mes FEV = Mes.FEVEREIRO;
		
		Tarefa tarefa1 = new Tarefa("teste");
		Tarefa tarefa2 = new Tarefa("OutraTarefa", 30,ABRIL , 2020);
		Tarefa tarefa3 = new Tarefa("TarefaCompleta",13, MAIO, 2019, 14, 55, 40);
		Tarefa tarefa4 = new Tarefa("Tarefa4");
		Tarefa tarefa5 = new Tarefa("Tarefa5", 31, OUTUBRO, 1989);
		Tarefa tarefa6 = new Tarefa("Bissexto",29, FEV, 2012, 23, 59, 59);
		Tarefa tarefa7 = new Tarefa("NAO Bissexto", 28, FEV, 2011, 23, 59, 59);
		Tarefa tarefa8 = new Tarefa("Tarefa8", 32, OUTUBRO, 1989);
		
		
		System.out.println(tarefa1); //data e hora padrao definido com 00
		System.out.println();
		System.out.println(tarefa2);//hora padrao definido com 00
		System.out.println();
		System.out.println(tarefa3);
		System.out.println();
		System.out.println(tarefa4); //data e hora padrao definido com 00
		System.out.println();
		System.out.println(tarefa5);
		System.out.println();
		System.out.println(tarefa6);
		System.out.println();
		System.out.println(tarefa7);
		System.out.println();
		System.out.println(tarefa8); //dia tem que retornar 00

	}

}
