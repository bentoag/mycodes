package livrodenotas.bento;

public class Curso {

	public static void main(String[] args) {			
		
		if(args.length == 3) {
			double [] [] medias;
			medias = new double [Integer.parseInt(args[1])][1];
			
			Tela.boasVindas();
			
			LivroNotas caderno = new LivroNotas(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]));
			
			for (int i = 0; i < Integer.parseInt(args[1]); i++) {
				
				for (int j = 0; j < Integer.parseInt(args[2]); j++) {
					caderno.adicionarNota(Tela.pedirNota(i), i, j);
				}
				
			}
			
			for (int i = 0; i < Integer.parseInt(args[1]); i++) {
				medias[i][0] = caderno.calcularMediaPorAluno()[i];
			}
			
		
			Tela.imprimeMedia(caderno.calcularMediaPorAluno(0), args[0], 0);//aluno 0
			System.out.println();			
			Tela.imprimeMedia(caderno.calcularMediaPorAluno(1), args[0], 1);////aluno 1
			System.out.println();	
			Tela.imprimeMedias(medias, args[0]);
		}else {
			System.out.println("Tente novamente! Par�metros incorretos");
		}
			
	}

}
