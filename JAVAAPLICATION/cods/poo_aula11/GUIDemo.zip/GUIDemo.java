import javax.swing.JFrame;

public class GUIDemo {
	public static void main(String[] args) {
		JFrame frame = null;

//		frame = new PrincipalFrame();
//		frame = new ButtonFrame();
//		frame = new BorderLayoutFrame();
//		frame = new FlowLayoutFrame();
//		frame = new GridLayoutFrame();
//		frame = new BoxLayoutFrame();
//		frame = new GridBagLayoutFrame();
//		frame = new NullLayoutFrame();
//		frame = new PanelFrame();
//		frame = new InputFieldsFrame();
//		frame = new EventFrame();
//		frame = new ActionEventFrame();
//		frame = new ItemEventFrame();
		frame = new ListSelectionFrame();
		
		frame.setVisible(true);
	}
}
