class ATM {
  //Imutável
  final int numeroSerie;

  //Mutável
  private int ctcinco;
  private int ctdez;
  private int ctvinte;
  private int ctcinquenta;
  private int ctcem;
  private int qtdcinco;
  private int qtddez;
  private int qtdvinte;
  private int qtdcinquenta;
  private int qtdcem;
  private int qtdnotas;
  private int valortotal;
  private int retiradas;


    ATM(int num){
      this.numeroSerie = num;
      //Auxiliar saque
      this.ctcinco = 0;
      this.ctdez = 0;
      this.ctvinte = 0;
      this.ctcinquenta = 0;
      this.ctcem = 0;

      //Auxiliar quantidade

      this.qtdcem = 0;
      this.qtdcinquenta = 0;
      this. qtdvinte = 0;
      this.qtddez = 0;
      this.qtdcinco = 0;

      this.qtdnotas = 0;
      this.valortotal = 0;
      this.retiradas = 0;

    }

      void abastecer (int qtd, int valorcd){
        if (valorcd == 100 && (qtd <=100) && (this.qtdcem +qtd) <=100) {
          this.qtdcem = (this.qtdcem + qtd);
        }else if (valorcd == 50 && (qtd <=100) && (this.qtdcinquenta +qtd) <=100) {
          this.qtdcinquenta = (this.qtdcinquenta + qtd);
        }else if (valorcd == 20 && (qtd <=100) && (this.qtdvinte +qtd) <=100) {
          this.qtdvinte = (this.qtdvinte + qtd);
        }else if (valorcd == 10 && (qtd <=100) && (this.qtddez+qtd) <=100) {
        this.qtddez = (this.qtddez + qtd);
      }else if (valorcd == 5 && (qtd <=100) && (this.qtdcinco +qtd) <=100) {
          this.qtdcinco = (this.qtdcinco + qtd);
        }else {
          System.out.println("Valor de Abastecimento Inválido");
        }
      }

      void retirar(int sq){

          //Priorizar saida de cedulas maiores
          //se a combinação de cedulas não atender o valor deve ser rejeitado (Ex cd 100 e 50 e retirar 60)
          //interface para consultar numero de cédulas
        if (sq <= this.valortotal ) {
          //inicializa com valor total de cédulas
          int ntcem= 0;
          int ntcinquenta = 0;
          int ntvinte = 0;
          int ntdez = 0;
          int ntcinco = 0;
          int auxsq = sq;

          while (auxsq > 100 && ntcem >= 0) {  //usar apenas variáveis locais para contagem
            ntcem= ntcem + 1;
            auxsq = auxsq - 100;
          }

          while (auxsq > 50  && ntcinquenta >= 0) {
            ntcinquenta = ntcinquenta + 1;
            auxsq = auxsq - 50;
          }

          while (auxsq > 20  && ntvinte >= 0 ) {
            ntvinte = ntvinte + 1;
            auxsq = sq - 20;
          }

          while (auxsq > 10 && ntdez >= 0) {
            ntdez = ntdez + 1;
            auxsq = auxsq - 10;
          }

          while (auxsq > 5 && ntcinco >= 0) {
            ntcinco = ntcinco + 1;
            auxsq = auxsq - 5;
          }
          if (auxsq == 0) {
            this.ctcem = ntcem;  //ctcem inicializa em zero e recebe qtd de notas retiradas no saque
            this.ctcinquenta = ntcinquenta;
            this.ctvinte = ntvinte;
            this.ctdez = ntdez;
            this.ctcinco = ntcinco;
            this.retiradas = sq;
          }
        }
      }

    int consultarQuantidade (int valorcd){
      if (valorcd == 100) {
        this.qtdnotas = this.qtdcem - this.ctcem;
      }else if (valorcd == 50){
        this.qtdnotas = this.qtdcinquenta - this.ctcinquenta;
      }else if (valorcd == 20) {
        this.qtdnotas = this.qtdvinte - this.ctvinte;
      }else if (valorcd == 10) {
        this.qtdnotas = this.qtddez - this.ctdez;
      }else if (valorcd == 5) {
        this.qtdnotas = this.qtdcinco - this.ctcinco;
      }else{
        this.qtdnotas = 0;
      }

      return this.qtdnotas;
    }
      int consultarValor () {

        this.valortotal = ((100*this.qtdcem)+(50*this.qtdcinquenta)+(20*this.qtdvinte)+(10*this.qtddez)+(5*this.qtdcinco))- this.retiradas;
        return this.valortotal;
      }
}
