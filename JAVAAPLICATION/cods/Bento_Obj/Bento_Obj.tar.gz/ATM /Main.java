class Main{
  public static void main(String[] args) {
    ATM atm = new ATM(2344499);
    System.out.println(atm.numeroSerie == 2344499);
    //atm.numeroSerie = 34883444;
    System.out.println();
    System.out.println(atm.consultarValor());
    System.out.println(atm.consultarValor() == 0);
    System.out.println();
    // abastecendo com 33 notas de 100
    atm.abastecer(15, 100);
    // System.out.println("Abastecimento 100");
    // atm.abastecer(66, 100);
    // atm.abastecer(4, 100);

    // verificando a quantidade de cédulas de 100
    // System.out.println(atm.consultarQuantidade(100)); // 33
    // // espera-se 33 cédulas
    // System.out.println(atm.consultarQuantidade(100) == 33);
    // // espera-se nenhuma cédula de qualquer outro valor
    // System.out.println(atm.consultarQuantidade(5)); // 0
    // System.out.println(atm.consultarQuantidade(5) == 0);
    // System.out.println(atm.consultarQuantidade(50)); // 0
    // System.out.println(atm.consultarQuantidade(50) == 0);
    // System.out.println(atm.consultarQuantidade(3)); // 0
    // System.out.println(atm.consultarQuantidade(3) == 0);
    // System.out.println();
    // atm.abastecer(8, 3); // 8 cédulas de R$ 3,00
    // System.out.println(atm.consultarQuantidade(3) == 0);
    // System.out.println();
    // System.out.println(atm.consultarValor()); // 33 * 100 = 3300 reais
    // System.out.println(atm.consultarValor() == 3300);
    // System.out.println();

    // atm.retirar(350);
    // System.out.println(atm.consultarValor());
    // System.out.println(atm.consultarQuantidade(100));
    // System.out.println(atm.consultarQuantidade(50));
    // System.out.println();

    atm.retirar(1000); // 3 cédulas de 100
    System.out.println(atm.consultarQuantidade(100));
    System.out.println(atm.consultarValor());
    System.out.println();
    // atm.retirar(3100); // não há cédulas suficientes
    // System.out.println(atm.consultarQuantidade(100) == 30);
    // System.out.println(atm.consultarValor() == 3000);
    // System.out.println();
    // atm.retirar(3000); // vai esvaziar o ATM
    // System.out.println(atm.consultarQuantidade(100));
    // System.out.println(atm.consultarValor());
    // System.out.println();
    // atm.abastecer(10, 10); // 10 cédulas de R$ 10,00
    // atm.abastecer(10, 50); // 10 cédulas de R$ 50,00
    // System.out.println(atm.consultarQuantidade(10) == 10);
    // System.out.println(atm.consultarQuantidade(50) == 10);
    // System.out.println(atm.consultarValor() == 600);
    // System.out.println();
    // // atm.retirar(100); // retira 2 cédulas de R$ 50,00
    // // System.out.println(atm.consultarQuantidade(10) == 10);
    // // System.out.println(atm.consultarQuantidade(50)==8);
    // // System.out.println(atm.consultarValor() == 500); // 10 * 10 + 8 * 50
    // // retirada combinada
    // atm.retirar(90); // 1 cédula de R$ 50,00 e 4 cédulas de R$ 10,00
    // System.out.println(atm.consultarQuantidade(10) == 6);
    // System.out.println(atm.consultarQuantidade(50) == 7);
    // System.out.println(atm.consultarValor() == 410);
    // System.out.println();
    //
    // //Casos Testes Adicionais
    // atm.abastecer(10, 5);
    // atm.abastecer(4, 10);
    // atm.abastecer(10, 20);
    // atm.abastecer(3, 50);
    // atm.abastecer(10, 100);
    // //CASO 1: COmbinando 4 cédulas
    // atm.retirar(335); // 1 de R$ 5,00  1 de R$ 10,00  1 de R$ 20,00 e 3 de R$100,00
    // System.out.println(atm.consultarQuantidade(5) == 9);
    // System.out.println(atm.consultarQuantidade(10) == 9);
    // System.out.println(atm.consultarQuantidade(20) == 9);
    // System.out.println(atm.consultarQuantidade(50) == 10);
    // System.out.println(atm.consultarQuantidade(100) == 7);
    // System.out.println(atm.consultarValor() == 1515); //1800 - 335
    // System.out.println();
    // //CASO 2: Combinando 5 cédulas
    // atm.retirar(995); // 1 de R$ 5,00  1 de R$ 10,00  4 de R$ 20,00, 4 de R$50,00 e 7 de R$100,00
    // System.out.println(atm.consultarQuantidade(5) == 8);
    // System.out.println(atm.consultarQuantidade(10) == 8);
    // System.out.println(atm.consultarQuantidade(20) == 5);
    // System.out.println(atm.consultarQuantidade(50) == 6);
    // System.out.println(atm.consultarQuantidade(100) == 0);
    // System.out.println(atm.consultarValor() == 520); //1515 - 995
    // System.out.println();
    // //CASO 3: Combinando 3 cédulas
    // atm.retirar(130); // 1 de R$ 10,00  1 de R$ 20,00 e 2 de R$50,00
    // System.out.println(atm.consultarQuantidade(5) == 8);
    // System.out.println(atm.consultarQuantidade(10) == 7);
    // System.out.println(atm.consultarQuantidade(20) == 4);
    // System.out.println(atm.consultarQuantidade(50) == 4);
    // System.out.println(atm.consultarQuantidade(100) == 0);
    // System.out.println(atm.consultarValor() == 390); //520 - 130
    // System.out.println();
    // //Caso Crítico (4 de R$20,00)
    // atm.retirar(85);
    // System.out.println(atm.consultarQuantidade(5));
    // System.out.println(atm.consultarQuantidade(10));
    // System.out.println(atm.consultarQuantidade(20));
    // System.out.println(atm.consultarQuantidade(50));
    // System.out.println(atm.consultarQuantidade(100));
    // System.out.println(atm.consultarValor()); //520 - 130
    // System.out.println();
  }
}
